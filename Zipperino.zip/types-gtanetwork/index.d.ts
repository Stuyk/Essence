/// <reference path="System.d.ts" />
/// <reference path="System.Drawing.dll.d.ts" />
/// <reference path="Xilium.CefGlue.dll.d.ts" />

/// <reference path="ScriptHookVDotNet.dll.d.ts" />

/// <reference path="GTANetworkShared.dll.d.ts" />
/// <reference path="GTANetwork.dll.d.ts" />
/// <reference path="NativeUI.dll.d.ts" />

/// <reference path="Declarations.d.ts" />
/// <reference path="Enums.ts" />